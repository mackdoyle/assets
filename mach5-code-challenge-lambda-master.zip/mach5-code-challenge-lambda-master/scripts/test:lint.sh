#!/bin/bash

# Get directory path of *this* script file and exit if is not set, NULL, or an empty string
SCRIPTS_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd -P )"
SCRIPTS_DIR="${SCRIPTS_DIR:?}"
ROOT_DIR="${SCRIPTS_DIR}/.."
BIN_DIR="${ROOT_DIR}/node_modules/.bin"

# This function runs linting tests against all .js files, except as ignored.
#     Ignores all files included in .gitignore.
#     Formats according to Nike's eslint-multi-formatter.
#     Linting rules per .estlintrc, which is extended from airbnb/base
  "${BIN_DIR}"/eslint \
    --color \
    --ignore-path="${ROOT_DIR}/.gitignore" \
    --format "${ROOT_DIR}/node_modules/@nike/eslint-multi-formatter/index.js" \
    "${ROOT_DIR}/**/*.js" # Run against all .js files
