#!/bin/bash

# Get directory path of *this* script file and exit if is not set, NULL, or an empty string
SCRIPTS_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd -P )"
SCRIPTS_DIR="${SCRIPTS_DIR:?}"
ROOT_DIR="${SCRIPTS_DIR}/.."
BIN_DIR="${ROOT_DIR}/node_modules/.bin"
REPORTS_DIR="${ROOT_DIR}/reports/unit"
TEST_DIR="${ROOT_DIR}/test"

"${BIN_DIR}/nyc" \
  --report-dir "${REPORTS_DIR}/coverage" \
  --reporter=text \
  --reporter=lcov \
  --reporter=json-summary \
  mocha \
    --colors \
    -R mochawesome \
    --reporter-options reportDir="${REPORTS_DIR}" \
    --recursive "${TEST_DIR}/**/*.unit.js" \
    --recursive "${TEST_DIR}/**/*.integration.js"