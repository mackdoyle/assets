# Mach5 Code Challenge: Lambda
> This assignment is designed to take about 4 hours. Please note, however, that many areas are intentionally left open-ended in order to accommodate many different skill levels. Do your best and enjoy!

## Lambda, I Choose You!

Hello Candidate! Our client, a local PokeGym, requires help matching each trainer with their ideal Pokemon match. Conveniently, all of the trainers are also registered GitHub users. The PokeGym would like a RESTful service that (1) determines the ideal Pokemon for a given trainer based on the below provided business rules; and (2) provides mock battle results between two trainers based on the below provided business rules.

### Acceptance Criteria
1. `GET /pokemon_match/:username` - returns a pokemon resource per attached api spec.
1. `POST /pokemon_battle` - returns a battle outcome resource per attached api spec.
1. Use Node JS AWS Lambdas and an API Gateway.
1. The lambdas source code should be tested.
1. All resources must be version-controllable using infrastructure-as-code.
1. The project should be *deployable* to AWS, but you do not need to deploy it.

### Business Rules
The PokeGym's Product Owner has provided some basic guidelines on how to determine a trainer's ideal pokemon and battle outcomes.

#### GET /pokemon_match/:username
Each trainer's best match can be derived from the trainer's GitHub profile data. The algorithm is... 
1. The trainer's `id`, plus...
1. The sum of the trainer's `login` string [character codes](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/String/charCodeAt), plus...
1. The trainer's number of `public_repos`, then...
1. Modulus that sum (steps 1 to 3) by 151 and return the Pokemon whose `id` is the same as the remainder.

For example, the ideal Pokemon for trainer [octocat](https://api.github.com/users/octocat) is [Victreebel](https://pokeapi.co/api/v2/pokemon/71).

#### POST /pokemon_battle
In a Pokemon battle, two Pokemon are pitted against each other. There must be one winner and one loser. The outcome of a Pokemon battle shall be determined as follows:
1. Each Pokemon has six "stats": **speed**, **special-defense**, **special-attack**, **defense**, **attack**, and **hp**.
1. Compare all six stats between the two Pokemon. For every stat's `base_stat`, the Pokemon with the higher score gets one point. For example, if Pokemon A has **speed** of 20 and Pokemon B has a **speed** of 21, then Pokemon B gets one point.
1. Therefore, for each battle, there are up to six points awarded.
1. After comparing all six stats, the Pokemon with the most points is the winner.

## Resources
- [GitHub API](https://developer.github.com/v3/users/#response)
- [PokeAPI](https://pokeapi.co/)
- [AWS Lambda - The Basics](https://dev.to/adnanrahic/getting-started-with-aws-lambda-and-nodejs-1kcf)
- [Sample AWS Serverless Cloudformation: APIG & Lambda](https://docs.aws.amazon.com/lambda/latest/dg/with-apigateway-example-use-app-spec.html)

## Extra Credit
The client has also expressed interest in persisting battle results between trainers using AWS DynamoDB. If you so choose, you can prepare a quick design document on how you would implement a persistence solution with the pros and cons of your design choices.
